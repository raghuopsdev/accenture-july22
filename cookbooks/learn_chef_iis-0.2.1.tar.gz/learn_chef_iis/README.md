# learn_chef_iis

Installs and configures IIS, the W3SVC, and sets a basic home page. This cookbook is used by the Learn Chef tutorials. https://learn.chef.io
